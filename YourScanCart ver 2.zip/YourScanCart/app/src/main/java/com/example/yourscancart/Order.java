package com.example.yourscancart;

public class Order {
    String delivery_date, delivery_status, order_id;

    public Order(String delivery_date, String delivery_status, String order_id){
        this.delivery_date = delivery_date;
        this.delivery_status = delivery_status;
        this.order_id = order_id;
    }

    public String getDelivery_date() {
        return delivery_date;
    }

    public void setDelivery_date(String delivery_date) {
        this.delivery_date = delivery_date;
    }

    public String getDelivery_status() {
        return delivery_status;
    }

    public void setDelivery_status(String delivery_status) {
        this.delivery_status = delivery_status;
    }
}
